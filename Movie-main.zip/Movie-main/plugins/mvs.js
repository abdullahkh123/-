const {cmd , commands} = require('../command')
const config = require('../config')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, sleep, fetchJson} = require('../lib/functions')
const foot = `©ABDULLAH KING 𝐎𝐅𝐂 💚`
var os = require('os')
cmd({
    pattern: "moviex",
    react: "📱",
    alias: ["mvdl","cinesubz"],
    desc: "Download movies from CineSubz.",
    category: "download",
    use: '.apk whatsapp',
    filename: __filename
},
async(conn, mek, m,{from, prefix, l, quoted, bodys, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
        if (!q) return reply('🚩 *Please provide a movie name to search*');
const res = await fetch(`https://rest-api-dark-shan.vercel.app/download/cinesubz-search?q=${q}`)
const aparade = await res.json();
const result = aparade.data;
const data = res.data
if (result.length < 1) return await conn.sendMessage(from, { text: N_FOUND }, { quoted: mek } )
var srh = [];  
for (var i = 0; i < result.length; i++) {
srh.push({
description: result[i].title,
title: i + 1,
rowId: prefix + 'cinesubzdl ' + result[i].link
});
}
const sections = [{
title: "_[Result from cinesubz.]_",
rows: srh
}]
const listMessage = {
text: `┌───[🧚‍♀️ABDULLAH-𝗠𝗗-𝗩❼💗]

   *MOVIE DOWNLOADER*

*🎬 Movie Name:* ${q}`,
footer: foot,
title: 'Result from Cinesubz. 🎬',
buttonText: '*🔢 Reply below number*',
sections
}
await conn.replyList(from, listMessage,{quoted: mek})
}catch(e){
console.log(e)
reply(`${e}`)
}
})

cmd({
    pattern: "cinesubzdl",
    react: "📱",
    alias: ["mvdl","cinesubz"],
    desc: "Download movies from CineSubz.",
    category: "download",
    use: '.apk whatsapp',
    filename: __filename
},
async(conn, mek, m,{from, prefix, l, quoted, bodys, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
        if (!q) return reply('🚩 *Please provide a movie name to search*');
const res = await fetch(`https://rest-api-dark-shan.vercel.app/download/cinesubz-dl?q=${q}`)
const aparade = await res.json();
const result = aparade.data;
const results = result.download
const data = res.data
const datas = aparade.download
const dls = aparade.downloadDetails
if (result.length < 1) return await conn.sendMessage(from, { text: N_FOUND }, { quoted: mek } )
var srh = [];  
for (var i = 0; i < results.length; i++) {
srh.push({
description: results[i].size,
title: i + 1,
rowId: prefix + 'cinedl ' + results[i].downloadDetails.DIRECT_LINK
});
	}
const sections = [{
title: "_[Result from cinesubz.]_",
rows: srh
}]
const listMessage = {
image: {url: aparade.image},
text: `┌───[🧚‍♀️ABDULLAH-𝗠𝗗-𝗩❼💗]\n\n*MOVIE DOWNLOADER*\n\n©𝐌𝐑 ABDULLAH 𝐎𝐅𝐂 💚\n\n
> 🔎 *SEARCH MOVIE NAME:* \`${result.title}\`\n
> 📅 *Date:* ${result.date}\n
> 🌍 *Country:* ${result.country}\n
> ⏳ *Duration:* ${result.duration}\n
> ⭐ *Rating:* ${result.rating}

> *⚖️𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 - : ©ABDULLAH KING  💚*
`,
footer: foot,
title: 'Result from Cinesubz. 🎬',
buttonText: '*🔢 Reply below number*',
sections
}
await conn.replyList(from, listMessage,{quoted: mek})
}catch(e){
console.log(e)
reply(`${e}`)
}
})

cmd({
    pattern: "cinedl",
    dontAddCommandList: true,
    filename: __filename
},
async(conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return await conn.sendMessage(from, { text: '*A download link is required.*' }, { quoted: mek });
        }

        await conn.sendMessage(from, { react: { text: '📥', key: mek.key } });

        let sendapk = await conn.sendMessage(from, {
            document: { url: q },
            mimetype: 'video/mp4',
            fileName: 'Qᴜᴇᴇɴ-ᴋᴇɴᴢɪ ᴍᴅ ᴠ2'
        }, { quoted: mek });

        await conn.sendMessage(from, { react: { text: '📁', key: sendapk.key } });
        await conn.sendMessage(from, { react: { text: '✔', key: mek.key } });
    } catch (e) {
        reply('*Error during file download!*');
        console.log(e);
    }
});
